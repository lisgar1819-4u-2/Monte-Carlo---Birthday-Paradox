/**************************************************************
Birthday Paradox with Monte Carlo Simulator

Student Name: Bin (Quoc Dat Phung)           Ms. Lindsay Cullum
Grade       : 11                            ICS4U
                                            Due  :  March 08, 2019

==> I spent 3 hours on this and nobody helped me. Not even Google.

OBJECTIVE:
     Calculate the probability of two people sharing the same birthday.
     There are 20 people in total.
****************************************************************/

#include <iostream>
using namespace std;
#include "apvector.h"
#include <math.h>
#include <stdlib.h>
#include <time.h>

///GLOBAL VARIABLES
const float numTest = 10000;                //total number of tests

///PROTOTYPES
void resetCounter(apvector<int>&counter);   //reset the content of counter
void resetStudents(apvector<int>&students); //reset the content of student birthdays

int main () {

///DECLARING APVECTOR ARRAYS & VARIABLES
    apvector <int> counter (365,0);         //365 positions in a year or 365 days in a calendar
    apvector <int> students (20,0);         //set of 20 integers or students
    float same;                             //increments when two people share the same birthday

    srand(time(0));                         // time seed


    ///********** INPUT **********///
    for (int i = 0; i < numTest; i++) {

        //reset arrays to get new inputs
        resetCounter(counter);
        resetStudents(students);

        //generate random numbers as birthdays for 20 students
        for (int i = 0; i < 20; i++) {
            //generate random numbers between 0 and 364 (not 365 because index starts at 0 not 1)
            //and put the random number into the elements of our student birthdays array
            //(the number of months here is not considered since we are considering the possible birth days...
            //in a whole year
            students[i] = rand()%364;
            /*for example, let's say the number 10 is generated. We put this number into the first index
            of our student birthday array. Also, we want to increment the content of index 10 in our
            counter (days in calendar) array, so 0 becomes one. I know this is confusing but I will explain
            the logic down below...

            Basically, this means that since 10 is generated, then one student's birthday is on the
            10th. Our counter have 365b indexes, each index acts as a day in a year. In index 10,
            or day 10, our content is 0, which means that nobody's birthday is on the 10th yet. We increment
            this number, which becomes one, because there's a person who has this birthday now.
            students[i] is 10.
            10 is the index or the day in our array
            incrementing 0 to one will result in the below...*/
            counter[students[i]]++;
        }

        //the below checks all the number of days in our array and see if there's a number larger than 1.
        // This would mean that if there are two people having the same day...
        //then increment the number of times two people have the same birthday.
        for (int i = 0; i < 365; i++) {
            if (counter[i] > 1) {
                same++;
            }
        }
        //There will be a huge number "same". This is okay, since we are looping it a lot of times.
        //Taking the number of "sames" and divide it by the total number that this loop is executed...
        // and multiply it by 100 will give you the percent or the probability.
    }

    ///********** OUTPUT **********///
    cout << "The probability of 2 out of 20 people having the same birthday is: " << same/numTest * 100 << "%" << endl;

    return 0;
}


void resetCounter(apvector<int>&counter) {
    for (int i = 0; i < 365; i++) {
        counter[i] = 0;
    }
}

void resetStudents(apvector<int>&students) {
    for (int i = 0; i < 20; i++) {
        students[i] = 0;
    }
}
